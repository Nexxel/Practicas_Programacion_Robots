DASHBOARD_TEST_FROM_CTEST
-------------------------

Environment variable that will exist when a test executed by CTest is run
in non-interactive mode. The value will be equal to :variable:`CMAKE_VERSION`.
