.. cmake-module:: ../../Modules/FindQt3.cmake
