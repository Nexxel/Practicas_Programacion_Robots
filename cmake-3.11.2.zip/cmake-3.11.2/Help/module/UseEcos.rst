.. cmake-module:: ../../Modules/UseEcos.cmake
